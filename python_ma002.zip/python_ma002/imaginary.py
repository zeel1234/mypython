no = complex(input("Enter Number : "));
print(no);
print(type(no));
