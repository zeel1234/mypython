n1 = (input("Enter some text here: "))
n2 = (input("Enter some text here: "))
if not n1.isnumeric() or not n2.isnumeric():
   print("This is not a number.")
else:
   sum =n1+n2;
   a=int(sum);
   print(a);
   print("This is  a number.")
