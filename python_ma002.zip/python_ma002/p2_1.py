no1=int(input("Enter Second number : "));
no2=int(input("Enter Second number : "));
sum = no1 + no2;
sub= no1 - no2 ;
mul= no1 * no2 ;
div= no1 / no2 ;
print(no1,"+",no2,"=",oct(sum));
print(no1,"-",no2,"=",oct(sub));
print(no1,"*",no2,"=",oct(mul));
print(no1,"/",no2,"=",oct(float(div)));

print(oct(11));
