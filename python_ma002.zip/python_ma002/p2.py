sum= no1 + no2 ;
sub= no1 - no2 ;
mul= no1 * no2 ;
div= no1 / no2 ;
print(no1,"+",no2,"=",sum);
print(no1,"-",no2,"=",sub);
print(no1,"*",no2,"=",mul);
print(no1,"/",no2,"=",div);




        
        
        
