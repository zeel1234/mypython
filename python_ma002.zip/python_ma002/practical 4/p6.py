import sys
args=sys.argv;
print(type(args));

cnt = len(sys.argv);
print("No. of arguments: ", cnt);


i=1;
sum = 0;
while(i<cnt):
    sum = sum + int(args[i]);
    i = i + 1;
    mins=min(args[i]);

print(" Minimum is:",mins)

print("Sum = ", sum);
print('bye');
