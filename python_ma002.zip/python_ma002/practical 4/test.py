n1=int(input("Enter n1"));
       
for i in range(1,n1,2):
    print(i)
