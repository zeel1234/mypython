import time
seconds = time.time()
print("Seconds since epoch =", seconds)
