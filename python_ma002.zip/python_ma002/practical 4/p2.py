import sys
args=sys.argv;
n1=int(args[1]);
n2=int(args[2]);

if(n1<n2):
    #print(n1, " < ", n2);
    i=n1;
    while(i<=n2):
        print(i);
        i=i+1;
else:
    #print(n2, " < ", n1);
    i=n1;
    while(i>=n2):
        print(i);
        i=i-1;
