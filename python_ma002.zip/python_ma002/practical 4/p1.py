n1=int(input("Enter First Number: "));
n2=int(input("Enter Second Number: "));


if(n1<n2):
    print(n1, " < ", n2);
    i=n1;
    while(i<=n2):
        print(i);
        i=i+1;
else:
    print(n2, " < ", n1);
    i=n1;
    while(i>=n2):
        print(i);
        i=i-1;

print('bye');
