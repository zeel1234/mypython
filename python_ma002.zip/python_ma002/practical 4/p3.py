import sys
import time 

args=sys.argv;
n1=int((args[1]));
import time
t1 = time.time()
print(" time befor executing programs =", t1)


if (n1 %2==0):
    print(n1,"is not prime");
else:
    print(n1,"is  prime");

t2 = time.time()
print("time after executing program =", t2)
t3=t2-t1;
print(t3)
