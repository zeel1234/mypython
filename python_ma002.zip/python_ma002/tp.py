no1=(input("Enter First number : "));
if(no1 == int(no1)):
     print("Numeric");
else:
     print("Not Numeric");
     
